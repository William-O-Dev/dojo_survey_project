from django.shortcuts import render, redirect

def index(request):
    return render(request, "index.html")

def result(request):
    # print(request.POST)
    if request.method == "GET":
        return redirect('/')
    language = []
    print(request.POST.getlist('language'))
    for languages in request.POST.getlist('language'):
        language.append(languages)
    context = {
        'first_name': request.POST['first_name'],
        'last_name': request.POST['last_name'],
        'email': request.POST['email'],
        'gender': request.POST['gender'],
        'campus': request.POST['campus'],
        'languages': language,
        'comments': request.POST['comments'],
    }
    return render (request, "result.html", context)
